\"\"\"Inference helper: load U-Net weights and run on two GeoTIFFs (t0,t1) and produce a change mask GeoTIFF.\"\"\"
import os
import numpy as np
import rasterio
try:
    import torch
    from models.unet import UNet
    TORCH_AVAILABLE = True
except Exception as e:
    TORCH_AVAILABLE = False

def read_band(path):
    with rasterio.open(path) as src:
        arr = src.read(1).astype('float32')
        prof = src.profile
    return arr, prof

def run_inference(t0_path, t1_path, model_path, out_path):
    t0, prof = read_band(t0_path)
    t1, _ = read_band(t1_path)
    # simple preprocessing
    eps = 1e-6
    t0_db = 10 * np.log10(np.abs(t0) + eps)
    t1_db = 10 * np.log10(np.abs(t1) + eps)
    # stack channels
    x = np.stack([t0_db, t1_db], axis=0)[None,...]  # (1,2,H,W)
    if TORCH_AVAILABLE and os.path.exists(model_path):
        model = UNet(n_channels=2, n_classes=1)
        state = torch.load(model_path, map_location='cpu')
        model.load_state_dict(state)
        model.eval()
        import torch.nn.functional as F
        xb = torch.from_numpy(x)
        with torch.no_grad():
            pred = model(xb)
            pred = torch.sigmoid(pred).numpy()[0,0]
        mask = (pred > 0.5).astype('uint8')*255
    else:
        # fallback: simple difference + Otsu
        diff = t1_db - t0_db
        from skimage import filters
        thresh = filters.threshold_otsu(diff)
        mask = (diff > thresh).astype('uint8')*255

    # save mask with same profile (single band uint8)
    prof.update(count=1, dtype=rasterio.uint8)
    with rasterio.open(out_path, 'w', **prof) as dst:
        dst.write(mask.astype(rasterio.uint8), 1)
    return out_path

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--t0', required=True)
    parser.add_argument('--t1', required=True)
    parser.add_argument('--model', default='models/model_unet.pth')
    parser.add_argument('--out', default='output/change_mask.tif')
    args = parser.parse_args()
    out = run_inference(args.t0, args.t1, args.model, args.out)
    print("Saved", out)