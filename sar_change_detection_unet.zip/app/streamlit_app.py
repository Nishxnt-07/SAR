import streamlit as st
import numpy as np
import rasterio
from skimage import filters
import matplotlib.pyplot as plt
import tempfile
import os

st.title("SAR Change Detection — Prototype (Thresholding + U-Net)")

method = st.selectbox("Method", ["Otsu thresholding (classical)", "U-Net (AI model)"])
uploaded_t0 = st.file_uploader("Upload SAR image (t0) — GeoTIFF", type=["tif","tiff"])
uploaded_t1 = st.file_uploader("Upload SAR image (t1) — GeoTIFF", type=["tif","tiff"])

def read_band(file):
    path = file if isinstance(file, str) else file
    with rasterio.open(path) as src:
        arr = src.read(1).astype('float32')
        profile = src.profile
    return arr, profile

if uploaded_t0 and uploaded_t1:
    t0_path = os.path.join(tempfile.gettempdir(), "t0.tif")
    t1_path = os.path.join(tempfile.gettempdir(), "t1.tif")
    with open(t0_path, "wb") as f:
        f.write(uploaded_t0.getbuffer())
    with open(t1_path, "wb") as f:
        f.write(uploaded_t1.getbuffer())

    t0, prof = read_band(t0_path)
    t1, _ = read_band(t1_path)

    eps = 1e-6
    t0_db = 10 * np.log10(np.abs(t0) + eps)
    t1_db = 10 * np.log10(np.abs(t1) + eps)
    diff = t1_db - t0_db

    if method == "Otsu thresholding (classical)":
        thresh = filters.threshold_otsu(diff)
        change_mask = diff > thresh
    else:
        # try to use PyTorch-based inference if available
        try:
            import torch
            from models.unet import UNet
            model_path = os.path.join("models","model_unet.pth")
            if os.path.exists(model_path):
                model = UNet(n_channels=2, n_classes=1)
                state = torch.load(model_path, map_location='cpu')
                model.load_state_dict(state)
                model.eval()
                xb = np.stack([t0_db, t1_db], axis=0)[None,...]
                xb_t = torch.from_numpy(xb)
                with torch.no_grad():
                    pred = model(xb_t)
                    pred = torch.sigmoid(pred).numpy()[0,0]
                change_mask = pred > 0.5
            else:
                st.warning("Model weights not found at models/model_unet.pth — falling back to Otsu thresholding.")
                thresh = filters.threshold_otsu(diff)
                change_mask = diff > thresh
        except Exception as e:
            st.error("PyTorch not available in this environment. Install PyTorch to use U-Net or use the Docker image. Falling back to Otsu.")
            thresh = filters.threshold_otsu(diff)
            change_mask = diff > thresh

    st.markdown("### Difference (t1 - t0) and result")
    fig, ax = plt.subplots(1,3, figsize=(12,4))
    ax[0].imshow(t0_db, vmin=np.percentile(t0_db,5), vmax=np.percentile(t0_db,95))
    ax[0].set_title("t0 (dB)")
    ax[0].axis('off')
    ax[1].imshow(t1_db, vmin=np.percentile(t1_db,5), vmax=np.percentile(t1_db,95))
    ax[1].set_title("t1 (dB)")
    ax[1].axis('off')
    ax[2].imshow(change_mask, cmap='gray')
    ax[2].set_title("Change mask")
    ax[2].axis('off')
    st.pyplot(fig)

    # save mask to temp t1 path profile
    out_mask = (change_mask.astype('uint8')*255)
    prof.update(count=1, dtype=rasterio.uint8)
    out_path = os.path.join(tempfile.gettempdir(),"change_mask.tif")
    with rasterio.open(out_path, 'w', **prof) as dst:
        dst.write(out_mask.astype(rasterio.uint8), 1)
    with open(out_path, "rb") as f:
        st.download_button("Download change mask (GeoTIFF)", data=f.read(), file_name="change_mask.tif")
else:
    st.info("Upload two small GeoTIFF SAR images (t0 and t1) to run demo. Use the notebook to fetch sample Sentinel-1 tiles.")