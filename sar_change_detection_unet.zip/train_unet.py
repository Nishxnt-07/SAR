\"\"\"Training script for U-Net on SAR change detection datasets.
This is a skeleton that assumes you have preprocessed dataset directories with:
- images/  (pairs stacked as 2-channel images or separate folders for t0,t1)
- masks/   (binary masks)

It uses PyTorch and will save best model to models/model_unet.pth
\"\"\"
import os, argparse, time
import torch
from torch.utils.data import DataLoader, Dataset
import torch.nn as nn
import torch.optim as optim
from torchvision import transforms
from models.unet import UNet
from PIL import Image
import numpy as np

class SimplePairsDataset(Dataset):
    def __init__(self, images_dir, masks_dir, transform=None):
        self.images = sorted([os.path.join(images_dir,f) for f in os.listdir(images_dir) if f.endswith('.npy') or f.endswith('.npz')])
        self.masks = sorted([os.path.join(masks_dir,f) for f in os.listdir(masks_dir) if f.endswith('.npy') or f.endswith('.npz')])
        self.transform = transform

    def __len__(self):
        return len(self.images)

    def __getitem__(self, idx):
        x = np.load(self.images[idx])
        y = np.load(self.masks[idx])
        # ensure float32 and shapes: (C,H,W)
        x = x.astype('float32')
        y = y.astype('float32')
        if x.ndim == 2:
            x = np.expand_dims(x,0)
        if y.ndim == 2:
            y = np.expand_dims(y,0)
        return torch.from_numpy(x), torch.from_numpy(y)

def train(args):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = UNet(n_channels=args.in_ch, n_classes=1).to(device)
    criterion = nn.BCEWithLogitsLoss()
    optimizer = optim.Adam(model.parameters(), lr=args.lr)

    # Simple dataset placeholders - the user should prepare .npy files for quick training
    train_ds = SimplePairsDataset(args.train_images, args.train_masks)
    val_ds = SimplePairsDataset(args.val_images, args.val_masks)
    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=1, shuffle=False)

    best_loss = 1e9
    for epoch in range(args.epochs):
        model.train()
        running=0.0
        for xb, yb in train_loader:
            xb = xb.to(device)
            yb = yb.to(device)
            preds = model(xb)
            loss = criterion(preds, yb)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            running += loss.item()
        avg = running/len(train_loader) if len(train_loader)>0 else 0
        print(f"Epoch {epoch+1}/{args.epochs} train_loss={avg:.4f}")
        # val
        model.eval()
        vloss=0.0
        with torch.no_grad():
            for xb,yb in val_loader:
                xb=xb.to(device); yb=yb.to(device)
                preds = model(xb)
                loss = criterion(preds, yb)
                vloss += loss.item()
        vavg = vloss/len(val_loader) if len(val_loader)>0 else 0
        print(f"  val_loss={vavg:.4f}")
        if vavg < best_loss:
            best_loss = vavg
            torch.save(model.state_dict(), os.path.join('models','model_unet.pth'))
            print("  Saved best model.")

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--train_images', default='data/train/images')
    parser.add_argument('--train_masks', default='data/train/masks')
    parser.add_argument('--val_images', default='data/val/images')
    parser.add_argument('--val_masks', default='data/val/masks')
    parser.add_argument('--epochs', type=int, default=10)
    parser.add_argument('--batch_size', type=int, default=4)
    parser.add_argument('--lr', type=float, default=1e-4)
    parser.add_argument('--in_ch', type=int, default=2)
    args = parser.parse_args()
    train(args)