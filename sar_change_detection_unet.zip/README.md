# SAR Change Detection Platform — U-Net Deep Learning Edition (Prototype)

This repo adds a PyTorch U-Net model for SAR change detection (two-channel input: t0 & t1).

## What's new
- `models/unet.py` — PyTorch U-Net implementation.
- `train_unet.py` — Training skeleton (expects .npy inputs for quick experiments).
- `inference_unet.py` — Inference script: uses model if available, otherwise falls back to Otsu thresholding.
- Updated `app/streamlit_app.py` — Choose between classical Otsu and U-Net inference.
- `deployment/Dockerfile` — includes `torch` and other deps.

## Quick test (without GPU)
1. Build Docker image (recommended):
   ```bash
   docker build -t sar-unet-proto -f deployment/Dockerfile .
   docker run -p 8501:8501 sar-unet-proto
   ```
2. Or install requirements locally (may take a while because of torch):
   ```bash
   pip install -r requirements.txt
   streamlit run app/streamlit_app.py
   ```

## Demo model
- If `models/model_unet.pth` exists, Streamlit will attempt to use it. If PyTorch is not available locally, the app will fall back to Otsu thresholding.
- If you want a quick demo model, run a short training on tiny synthetic `.npy` tiles using `train_unet.py` (example in notebook stub) to create `models/model_unet.pth`.

## Notes on datasets
- Use public datasets like Sen1Floods11 or OSCD. Preprocess into small `.npy` pairs for faster experimentation.
- See original `deployment/links_and_notes.md` for dataset links and tips.